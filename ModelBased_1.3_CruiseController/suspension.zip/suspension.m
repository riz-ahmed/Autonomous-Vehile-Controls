%---------------------------------------------------
% Exercises on 2.4.2 - Suspension system model
% Vehicle parameters
%---------------------------------------------------
        
mc=401;                         % Quarter car mass [kg]
mw=48;                          % Wheel mass [kg]
ds=5000;                        % Suspension damping coefficient [Ns/m]
cs=10000;                       % Suspension spring coefficient [N/m]
cw=250000;                      % Wheel spring coefficient [N/m]

%---------------------------------------------------
% Enter your matrices here
%---------------------------------------------------
%A=
%B=
%C=
%D=
%---------------------------------------------------
